# EGO PvP Website

A bilingual (English / Arabic) responsive website with:
- EGO PvP landing page using your logo
- Live streamer cards managed from the admin dashboard
- Shop for weapons, cars and VIP offers
- Staff application form (name, nickname, age, Discord ID, reason)
- Shop request form
- PVP rules in English and Arabic
- Admin dashboard to add/edit/delete products, streamers and rules
- Separate Discord webhooks for staff applications and shop requests
- Optional Discord OAuth sign-in button

## Requirements
- Node.js 18 or newer
- Discord server and two Discord webhooks (one for staff applications, one for shop requests)

## Run on Windows
1. Extract the ZIP.
2. Install Node.js 18+ if it is not installed.
3. Open the extracted `ego-pvp-site` folder.
4. Copy `.env.example` to a new file named `.env`.
5. Edit `.env` and set a strong `SESSION_SECRET`, `ADMIN_PASSWORD`, `STAFF_WEBHOOK_URL`, and `SHOP_WEBHOOK_URL`.
6. Open Command Prompt in this folder and run:
   ```bash
   npm install
   npm start
   ```
7. Open `http://localhost:3000`.
8. Open `http://localhost:3000/admin.html` to manage the site.

## Connect Discord webhooks
In Discord, create one webhook for the staff-application channel and another for the shop-request channel. Paste their URLs into `.env`:
- `STAFF_WEBHOOK_URL=...`
- `SHOP_WEBHOOK_URL=...`

Do not paste webhook URLs into `public/app.js`, HTML, or any public frontend code.

## Discord OAuth (optional)
Create an application at https://discord.com/developers/applications, add the OAuth2 redirect URL matching `DISCORD_REDIRECT_URI`, and set `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, and `DISCORD_REDIRECT_URI` in `.env`. The login button uses the OAuth2 `identify` scope. This starter does not automatically grant admin permissions based only on Discord login; the admin dashboard uses the separate `ADMIN_PASSWORD`.

## Add / remove products
Visit `/admin.html`, log in, open **Shop Products**, then add, edit or delete items and press **Save Products**. Add direct HTTPS image links to show product images. Product data is saved to `data/site-data.json`.

## Live streamers
Open **Live Streamers** in the admin dashboard. Add the streamer's name and channel URL, then tick **Live Now** and save. Untick it or delete the card when the streamer ends their live.

## Important before public hosting
- Use HTTPS.
- Set a long random `SESSION_SECRET` and a strong `ADMIN_PASSWORD`.
- Keep `.env` private and never upload it publicly.
- The default session store is intended for a starter/small deployment; use a persistent production session store for a serious public launch.
- This is a website template, not a payment processor. The shop sends purchase inquiries to Discord; it does not automatically charge money.
