require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "site-data.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultData = {
  products: [
    { id: "p1", name: "EGO Rifle", nameAr: "سلاح EGO", category: "Weapons", categoryAr: "أسلحة", price: "Contact us", image: "", description: "Add your weapon details here.", descriptionAr: "أضف تفاصيل السلاح هنا.", vip: false },
    { id: "p2", name: "EGO VIP Car", nameAr: "سيارة VIP", category: "Cars", categoryAr: "سيارات", price: "VIP", image: "", description: "VIP vehicle offer.", descriptionAr: "عرض سيارة VIP.", vip: true }
  ],
  streamers: [],
  rules: [
    { en: "Respect all players and staff.", ar: "احترم جميع اللاعبين وأعضاء الستاف." },
    { en: "No cheating, exploits, or unfair advantages.", ar: "ممنوع الغش أو استغلال الثغرات أو استعمال أفضلية غير عادلة." },
    { en: "Follow staff instructions during disputes.", ar: "اتبع تعليمات الستاف عند حدوث أي خلاف." },
    { en: "Keep chat and voice channels respectful.", ar: "حافظ على الاحترام في الدردشة والقنوات الصوتية." }
  ],
  settings: { discordInvite: "", accent: "#ff2424" }
};

function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify(defaultData, null, 2));
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch (e) {
    console.error("Could not read site data:", e.message);
    return JSON.parse(JSON.stringify(defaultData));
  }
}
let data = loadData();
function saveData() { fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); }

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "200kb" }));
app.use(express.urlencoded({ extended: false, limit: "30kb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-before-deploying",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 50, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const isAdmin = (req, res, next) => {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: "Admin login required." });
};
const clean = (v, max = 500) => String(v ?? "").trim().slice(0, max);
const safeUrl = (v) => {
  const s = clean(v, 1000);
  if (!s) return "";
  try { const u = new URL(s); return ["http:", "https:"].includes(u.protocol) ? s : ""; } catch { return ""; }
};

app.get("/api/site", (req, res) => {
  res.json({
    products: data.products,
    streamers: data.streamers,
    rules: data.rules,
    settings: data.settings,
    discordLoginEnabled: Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET)
  });
});

app.post("/api/apply-staff", async (req, res) => {
  const name = clean(req.body.name, 80);
  const nickname = clean(req.body.nickname, 80);
  const age = clean(req.body.age, 3);
  const discordId = clean(req.body.discordId, 40);
  const reason = clean(req.body.reason, 1500);
  const honeypot = clean(req.body.company, 100);
  if (honeypot) return res.json({ ok: true });
  if (!name || !nickname || !age || !discordId || !reason) return res.status(400).json({ error: "Please fill in every field." });
  if (!/^\d{1,3}$/.test(age) || Number(age) < 13 || Number(age) > 99) return res.status(400).json({ error: "Please enter a valid age." });
  if (!/^\d{15,22}$/.test(discordId)) return res.status(400).json({ error: "Discord ID should contain 15–22 digits." });
  if (!process.env.STAFF_WEBHOOK_URL) return res.status(503).json({ error: "Staff applications are not configured yet. Add STAFF_WEBHOOK_URL in .env." });
  const payload = {
    username: "EGO PvP • Staff Applications",
    embeds: [{
      title: "📝 New Staff Application",
      color: 16720932,
      fields: [
        { name: "Name", value: name, inline: true },
        { name: "Nickname", value: nickname, inline: true },
        { name: "Age", value: age, inline: true },
        { name: "Discord ID", value: discordId, inline: false },
        { name: "Why do you want to join the staff team?", value: reason, inline: false }
      ],
      timestamp: new Date().toISOString(),
      footer: { text: "EGO PvP • Website" }
    }]
  };
  try {
    const r = await fetch(process.env.STAFF_WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (!r.ok) throw new Error("Discord webhook returned " + r.status);
    res.json({ ok: true, message: "Application sent successfully." });
  } catch (e) { console.error(e.message); res.status(502).json({ error: "Could not send the application to Discord. Check the staff webhook." }); }
});

app.post("/api/shop-request", async (req, res) => {
  const item = clean(req.body.item, 120);
  const player = clean(req.body.player, 80);
  const discordId = clean(req.body.discordId, 40);
  if (!item || !player || !discordId) return res.status(400).json({ error: "Please fill in all fields." });
  if (!/^\d{15,22}$/.test(discordId)) return res.status(400).json({ error: "Discord ID should contain 15–22 digits." });
  if (!process.env.SHOP_WEBHOOK_URL) return res.status(503).json({ error: "Shop requests are not configured yet. Add SHOP_WEBHOOK_URL in .env." });
  try {
    const r = await fetch(process.env.SHOP_WEBHOOK_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: "EGO PvP • Shop", embeds: [{ title: "🛒 New Shop Request", color: 16720932, fields: [
        { name: "Item", value: item, inline: true }, { name: "Player", value: player, inline: true }, { name: "Discord ID", value: discordId }
      ], timestamp: new Date().toISOString() }] })
    });
    if (!r.ok) throw new Error("Discord webhook returned " + r.status);
    res.json({ ok: true, message: "Request sent successfully." });
  } catch (e) { console.error(e.message); res.status(502).json({ error: "Could not send the shop request to Discord." }); }
});

app.post("/api/admin/login", (req, res) => {
  const password = String(req.body.password || "");
  if (!process.env.ADMIN_PASSWORD) return res.status(503).json({ error: "Set ADMIN_PASSWORD in .env first." });
  if (password !== process.env.ADMIN_PASSWORD) return res.status(401).json({ error: "Incorrect password." });
  req.session.isAdmin = true;
  res.json({ ok: true });
});
app.post("/api/admin/logout", isAdmin, (req, res) => { req.session.destroy(() => res.json({ ok: true })); });
app.get("/api/admin/status", (req, res) => res.json({ isAdmin: Boolean(req.session && req.session.isAdmin) }));

app.put("/api/admin/products", isAdmin, (req, res) => {
  if (!Array.isArray(req.body.products) || req.body.products.length > 200) return res.status(400).json({ error: "Invalid product list." });
  data.products = req.body.products.map(p => ({
    id: clean(p.id, 80) || "p" + Date.now() + Math.random().toString(16).slice(2, 6),
    name: clean(p.name, 100), nameAr: clean(p.nameAr, 100),
    category: clean(p.category, 40), categoryAr: clean(p.categoryAr, 40),
    price: clean(p.price, 80), image: safeUrl(p.image),
    description: clean(p.description, 500), descriptionAr: clean(p.descriptionAr, 500), vip: Boolean(p.vip)
  })).filter(p => p.name);
  saveData(); res.json({ ok: true, products: data.products });
});
app.put("/api/admin/streamers", isAdmin, (req, res) => {
  if (!Array.isArray(req.body.streamers) || req.body.streamers.length > 100) return res.status(400).json({ error: "Invalid streamer list." });
  data.streamers = req.body.streamers.map(s => ({
    id: clean(s.id, 80) || "s" + Date.now() + Math.random().toString(16).slice(2, 6),
    name: clean(s.name, 100), platform: clean(s.platform, 40),
    url: safeUrl(s.url), image: safeUrl(s.image), live: Boolean(s.live)
  })).filter(s => s.name && s.url);
  saveData(); res.json({ ok: true, streamers: data.streamers });
});
app.put("/api/admin/settings", isAdmin, (req, res) => {
  data.settings = { discordInvite: safeUrl(req.body.discordInvite), accent: /^#[0-9a-fA-F]{6}$/.test(req.body.accent || "") ? req.body.accent : "#ff2424" };
  saveData(); res.json({ ok: true, settings: data.settings });
});
app.put("/api/admin/rules", isAdmin, (req, res) => {
  if (!Array.isArray(req.body.rules) || req.body.rules.length > 50) return res.status(400).json({ error: "Invalid rules." });
  data.rules = req.body.rules.map(r => ({ en: clean(r.en, 500), ar: clean(r.ar, 500) })).filter(r => r.en || r.ar);
  saveData(); res.json({ ok: true, rules: data.rules });
});

app.get("/auth/discord", (req, res) => {
  if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_REDIRECT_URI) return res.redirect("/?discord=not-configured");
  const params = new URLSearchParams({ client_id: process.env.DISCORD_CLIENT_ID, redirect_uri: process.env.DISCORD_REDIRECT_URI, response_type: "code", scope: "identify" });
  res.redirect("https://discord.com/oauth2/authorize?" + params.toString());
});
app.get("/auth/discord/callback", async (req, res) => {
  try {
    if (!req.query.code || !process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_CLIENT_SECRET) return res.redirect("/?discord=failed");
    const body = new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID, client_secret: process.env.DISCORD_CLIENT_SECRET,
      grant_type: "authorization_code", code: String(req.query.code),
      redirect_uri: process.env.DISCORD_REDIRECT_URI
    });
    const tokenResp = await fetch("https://discord.com/api/oauth2/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
    const token = await tokenResp.json();
    if (!token.access_token) throw new Error("OAuth token exchange failed");
    const userResp = await fetch("https://discord.com/api/users/@me", { headers: { Authorization: "Bearer " + token.access_token } });
    const user = await userResp.json();
    req.session.discordUser = { id: user.id, username: user.global_name || user.username, avatar: user.avatar ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png` : "" };
    res.redirect("/");
  } catch (e) { console.error(e.message); res.redirect("/?discord=failed"); }
});
app.get("/api/me", (req, res) => res.json({ user: req.session.discordUser || null }));

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`EGO PvP is running at http://localhost:${PORT}`));
